package to_check_palindrome;

public class checkpalindrome {
    public static void main(String[] args) {
        int r, sum=0, temp;
        int n=454; //n would be checked for palindrome
        temp=n; //saving n to temp variable for checking weather the reversal of the no is same or not
        while(n!=0){
            r=n%10;
            sum=sum*10+r;
            n=n/10;
        }
        if(temp==sum){
            System.out.println(temp+" is a palindrome number");
        }else{
            System.out.println(temp+" is not a palindrome number");
        }
    }
    
}
