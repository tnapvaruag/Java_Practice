package to_check_palindrome;
import java.util.*;;//we imported this package as it contain functions related to string
class check_another_palindrome{
    public static void main(String[] args){
        String original,reverse=""; //objects of string class
        Scanner in = new Scanner(System.in);//to input the string/number
        System.out.println("Enter a string/number to check if it a palindrome or not!");
        original = in.nextLine();
        int length = original.length();//length function to gauge length of original variable
        for( int i=length-1; i>=0;i--){
            reverse=reverse+original.charAt(i);//charAt function to access the character on the basis of the index
        }
        if(original.equals(reverse)){//equals() functions to check if both variables consist of same value
            System.out.println("It is Palindrome");
        }else{
            System.out.println("It is not Palindrome");
        }
    }

    @Override
    public String toString() {
        return "check_another_palindrome []";
    }
}