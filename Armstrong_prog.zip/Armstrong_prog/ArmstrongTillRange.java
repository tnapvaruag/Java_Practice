package Armstrong_prog; //package is just the folder in which this file is sotred. It can be understand as bundle of different classes
import java.util.Scanner;// util scanner is inbuilt library having function to input different datatypes
import java.lang.Math;// math library stores various math functions like power which is used here

public class ArmstrongTillRange {//it is the class same name as the java file

    static boolean isArmstrong(int n){//function used to check armstrong which return boolean values i.e. true or false only
        int temp, last=0, digits=0, sum=0;// armstrong no--- n=xyz = x^3+y^3+z^3; where n is the number ; xyz displays 3 digits of the number n
        temp=n;
        while(temp>0){
            temp=temp/10;
            digits++;// digits is used to store total no of digit in the mumber n which will be used to find power of individual digit of the number
        }
        temp=n;
        while(temp>0){
            last=temp%10;
            sum+=(Math.pow(last,digits));// math function powers is used to store last^digit where last contain digits of number n one after another.
            temp=temp/10;
        }
        if(n==sum){return true;}//return type is boolean 
        else{return false;}

    }
    public static void main(String[] args) {// main function
        int num;
        Scanner sc = new Scanner(System.in);// scanner function of util library
        System.out.print("Enter the range : ");
        num= sc.nextInt();//num stores the range
        System.out.println("Armstrong Numbers Upto "+num+" are as follow !");
        for (int i=0; i<=num; i++){
            if(isArmstrong(i))//revoking isArmstrong function inside main function
              {System.out.print(i+" ");// printing the range in single line usin print function instead of print ln and ; should be used to avoid errors..
            }
        }        

    }
    
}
