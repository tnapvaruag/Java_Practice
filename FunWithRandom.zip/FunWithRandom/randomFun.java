package FunWithRandom;
import java.lang.Math;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class randomFun {

    public static void main(String[] args) {
        
        System.out.println("First Random no : "+ Math.random());/* This random function of math library is used to generate random numbers between 
        0.0 to 1.0 it generated double only */
        int max=400;
        int min=200;
            int a= (int) (Math.random()*(max-min+1)+min);// to print random number in a range between min and max
            System.out.println("Second Random No : "+ a);// it will give random nos in integer only as data type of a is specified as int
    
            double b= (double) (Math.random()*(max-min+1)+min);// to print random number in a range between min and max
            System.out.println("Third Random No : "+ b);// it will give random nos in double only as data type of a is specified as double

            float c= (float) (Math.random()*(max-min+1)+min);// to print random number in a range between min and max
            System.out.println("Fourth Random No : "+ c);// it will give random nos in float only as data type of a is specified as float
          

// Above all statements were using random function of math library to generate random numbers now we move on to using Random library of util

            Random x = new Random();//x is an object of class Random
            int z =x.nextInt(25,50);// in z integer type random no between origin and bound but bound excluded are generated 
            // 25 is origin and 50 is bound aboves
            System.out.println("First Random no using Util : "+z);
            Random l = new Random();//l is an object of class Random
            boolean m =l.nextBoolean();// in m boolean type random value will be generated generated 
            
            System.out.println("Second Random value using Util : "+m);//it will return true and false 


            x.ints(5,53,99).forEach(System.out::println);/*ints functions of Random class is 
            also used to generated random numbers with specified stream size eg. 5 */

            int o= ThreadLocalRandom.current().nextInt(10,14);
            System.out.println(o);//another class of util > concurrent > ThreadLoacalRandom can also be used to generate random numbers


            //random numbers of different data types can be generated using different functions like nextInt nextDouble

    }
    
}
