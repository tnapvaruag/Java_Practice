package prime_num;
 class prime_number {
    
    public static void main(String[] args) {//main function
        int i,m=0,flag=0; //variables initialisation
        int n=3; //this number is to be checked whether it is prime or not
        m=n/2; //2 is an only even prime number so to exclude two from the code at line 15 we use this statement
        if(n==0||n==1){// || is the symbolisation of OR function
            //0 and 1 are not prime numbers
            System.out.println(n+" is not a prime number");

        }
        else{
            for(i=2;i<=m;i++){//now we will check whether n is divisible by numbers from 2 and n/2
                if(n%i==0){ 
                    System.out.println(n+" is not a prime number");//prime numbers are those numbers divided by 1 and itself.
                    flag=1;
                    break;
                }
            }
        
            if(flag==0){
            System.out.println(n+" is a prime number");
            }
        }//end of else
    }
}
