package factorials_programs;

import java.util.*;
public class factorialByInput {
    

        public static void main(String[] args) {
            int i; long fact=1;
            
            Scanner z = new Scanner(System.in);//to input the number
            System.out.print("Enter a number: ");/*Earlier I was using println command which is asking for the input in the next line for taking
           input in same line we need to use only print command here */

            int num = z.nextInt();/*Earlier I used nextLine() in place of nextInt but the previous is used to import string while the later is used
            to import integers */
            for(i=1;i<=num;i++){
                fact=fact*i;
    
            }System.out.println("The factorial of "+num+" is: "+fact);
        }
    
      
    
}
