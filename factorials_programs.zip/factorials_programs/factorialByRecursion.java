package factorials_programs;

public class factorialByRecursion {

    static int factorialfan(int n){
        if(n==0){
            return 1;
        }else{
            return (n*factorialfan(n-1));
        }
    
    }

    public static void main(String[] args) {
        
        int i; long fact=1;
        int num=253;
        fact= factorialfan(num);
        System.out.println("The factorial of "+num+" is: "+fact);
    }
    
    
}
