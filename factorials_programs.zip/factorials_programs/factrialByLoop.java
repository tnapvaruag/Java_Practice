package factorials_programs;

public class factrialByLoop {
    public static void main(String[] args) {
        long fact=1;
        int num=15; //number to calculate factorial of.
        for(int i=1;i<=num;i++){
            fact=fact*i;

        }
        System.out.println("The factorial of "+num+" is: "+fact);
    }


    
}
