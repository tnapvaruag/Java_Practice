package fibonacci;

public class FibonacciWithoutRecursion {//fibonacci series without recursion 
    public static void main(String[] args) {
        int n1=0,n2=1,n3,i,count=10; //count=10 as printing series of 10 numbers
        System.out.print(n1+" "+n2);//printing 0 and 1 as first numbers of fibonacci series
    
        for(i=2;i<count;++i){//i=2 as two numbers already have printed out
                n3=n1+n2;
                n1=n2;
                n2=n3;
                System.out.print(" "+n3); //put some space between "" to give space between the output
        }
    }

}
