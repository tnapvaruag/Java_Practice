package fibonacci;
public class Fibonacciwithrecursion {// program to print fibonacci series using recursion
    static int n1=0,n2=1,n3=0;//global variables
    static void printfibonacci(int count){//function to print fibonacci numbers 
        if(count>0){
            n3=n1+n2;
            n1=n2;
            n2=n3;
            System.out.print(" "+n3);
            printfibonacci(count-1);

        }

    
    }
    public static void main(String[] args) {
        int count=10;
        System.out.print(n1+" "+n2);//print 0 and 1
        printfibonacci(count-2);//count-2 is used as 0 and 1 have already been printed out
    }
}
